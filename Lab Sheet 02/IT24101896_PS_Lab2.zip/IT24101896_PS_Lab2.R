#set the working directory 
setwd("C:\\Users\\IT24101896\\Desktop\\IT24101896")
getwd()

#Quwstion2
sum((1:15) %% 3 == 0)

#Question3
v <- c(4,9,2,15,6)
max_index <- 1

for(i in 2:length(v)) {
  if (v[i] > v [max_index]){
    max_index <- i
  }
}

print(max_index)

#Question4
vec <- c(4,9,2,15,6)
which.max(vec)
