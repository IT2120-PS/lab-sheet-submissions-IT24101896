#get the working directory
getwd()
#set the working directory
setwd("C:\\Users\\Jithmi Abewickrama\\Desktop\\IT24101896_Lab03")
getwd()

# Read the CSV into a data frame
student_data <- read.csv("Exercise.csv")

# View the first few rows to confirm
head(student_data)

# Summary statistics
summary(student_data$X1)

# Histogram
x11()
hist(student_data$X1,
     main = "Age Distribution",
     xlab = "Age",
     col = "skyblue",
     border = "black")


# Frequency table
table(student_data$X2)

# Bar chart
x11()
barplot(table(student_data$X2),
        main = "Gender Distribution",
        names.arg = c("Male", "Female"),
        col = c("blue", "pink"))

# Boxplot to compare age across accommodation types
x11()
boxplot(X1 ~ X3, data = student_data,
        main = "Age vs Accommodation Type",
        xlab = "Accommodation Type",
        ylab = "Age",
        col = c("lightgreen", "lightblue", "lightpink"))





