#Comments

#get the working directory 
getwd()

#set the working directory 
setwd("C:\\Users\\Jithmi Abewickrama\\Desktop\\2nd Year 1st Sem\\PS\\RStudio Lab1")
getwd()

setwd("C:/Users/Jithmi Abewickrama/Desktop/2nd Year 1st Sem/PS/RStudio Lab1")
getwd()

#help

?solve

help("data.frame")

#Question1
a<-10
b<-3

#Question2
a+b
a%/%b
a%%b
a^b

#Question3
isTRUE(a>b)
isTRUE(b==3)
isTRUE(a>5)|isTRUE(b<2)
scores<-c(85,90,78,92,NA,88)
class(scores)
mean(scores, na.rm = TRUE)
scores[scores > 85]

#Question5
names<-c("Alice","Bob","Charalin","Evan","Fiona")
passed <- scores >= 80
passed

#Question6
results <- data.frame(Name = names, Score = scores, Passed = passed)
print(results)

#Question7
str(results)
print(results)


#Question8
data<-data.frame(Name = c("Alice", "Bob", "Charlie"), Score = c(85, 92, 78))
max(data$Score)






















