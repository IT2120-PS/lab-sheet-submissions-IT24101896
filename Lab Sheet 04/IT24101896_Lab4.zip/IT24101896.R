#set the working directory
setwd("C:\\Users\\IT24101896\\Desktop\\IT24101896")
#get the working directory
getwd()

# Import dataset
branch_data <- read.table("Exercise.txt", header = TRUE)

# Boxplot for Sales
x11()
boxplot(branch_data$Sales,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue")
# Five-number summary
fivenum(branch_data$Advertising)

# Interquartile range
IQR(branch_data$Advertising)

# Function to detect outliers using IQR rule
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

# Check outliers in Years variable
find_outliers(branch_data$Years)
